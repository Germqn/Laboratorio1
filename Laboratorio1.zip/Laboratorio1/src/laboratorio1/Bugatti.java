/*
Proposito: Definicion de la clase Bugatti
Autores:
German Mejia - 202373276
Santiago Mafla
Sebastian Bolaños
Version:1.0
Fecha:31/08/2024
 */
package laboratorio1;

import java.util.Scanner;

public class Bugatti {
   String Color;
   int Vin, Precio , Modelo, VelocidadMax;
 
   Scanner sc = new Scanner(System.in);
   
   public void Bugatti(){
       Color = "-";
       Vin = Precio = Modelo = VelocidadMax = 0;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }
    
    public void setColor(){
        System.out.println("Ingrese el color del vehiculo: ");
        Color = sc.nextLine();
    }

    public int getPrecio() {
        return Precio;
    }

    public void setPrecio(int Potencia) {
        this.Precio = Potencia;
    }
    
    public void setPrecio(){
        System.out.println("Ingresa el precio del vehiculo: ");
        Precio = sc.nextInt();
    }

    public int getModelo() {
        return Modelo;
    }

    public void setModelo(int Modelo) {
        this.Modelo = Modelo;
    }
    
    public void setModelo() {
        System.out.println("Ingresa el modelo del vehiculo: ");
        Modelo = sc.nextInt();
    }

    public int getVelocidadMax() {
        return VelocidadMax;
    }

    public void setVelocidadMax(int VelocidadMax) {
        this.VelocidadMax = VelocidadMax;
    }
    
    public void setVelocidadMax() {
        System.out.println("Ingresa la velocidad maxima del vehiculo: ");
        VelocidadMax = sc.nextInt();
    }

    public int getVin() {
        return Vin;
    }

    public void setVin(int Vin) {
        this.Vin = Vin;
    }
    
    public void setVin() {
        System.out.println("Ingrese el vin del vehiculo:");
        Vin = sc.nextInt();
    }

    @Override
    public String toString() {
        return "Bugatti{" + "Color=" + Color + ", Vin=" + Vin + ", Potencia=" + Potencia + ", Modelo=" + Modelo + ", VelocidadMax=" + VelocidadMax + '}';
    }
}


