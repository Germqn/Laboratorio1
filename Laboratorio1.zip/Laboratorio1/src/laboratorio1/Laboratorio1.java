/*
Proposito:Aplicación que permita almacenar en un ArrayList los datos de cualquier 
entidad (persona, cosa, lugar, …., etc).
Autores:
German Mejia - 202373276
Santiago Mafla
Sebastian Bolaños
Version:1.0
Fecha:31/08/2024
 */
package laboratorio1;

import java.util.ArrayList;
import java.util.Scanner;

public class Laboratorio1 {
    ArrayList<Bugatti> arr = new ArrayList<>();
    Scanner sc = new Scanner(System.in);
    
    public void leerDatos(){Bugatti obj1 = new Bugatti();
        obj1.setVin();
        if (existe(obj1.getVin())) {
            System.out.println("Vehiculo con el vin ya existe :3");
        } else {
            obj1.set();
            obj1.setNom();
            System.out.println("Ingrese programa: ");
            int prog = sc.nextInt();
            obj1.setPrograma(prog);
            arr.add(obj1);
        }}
    
       public boolean existe(int VinBuscar){
        for (Bugatti bugat : arr) {
            if(bugat.getVin()== VinBuscar) return true;
        }
        return false;
    }
            
    public static void main(String[] args) {
        Laboratorio1 s = new Laboratorio1();
    }            
 }
  




